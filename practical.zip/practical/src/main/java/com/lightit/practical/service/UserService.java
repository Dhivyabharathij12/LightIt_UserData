package com.lightit.practical.service;

import com.lightit.practical.model.User;
import com.lightit.practical.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> getAllUsers() {
        return userRepository.readUsersFromFile();
    }

    public Optional<User> findByUsernameAndPassword(String username, String password) {
        return userRepository.readUsersFromFile().stream()
                .filter(u -> u.getUserName().equalsIgnoreCase(username) && u.getPassword().equals(password))
                .findFirst();
    }
}
