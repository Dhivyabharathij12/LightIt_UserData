package com.lightit.practical.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    private int id;
    private String key;
    private String type;

    @JsonProperty("firstName")
    private String name;

    @JsonProperty("username")
    private String userName;

    private String paternalLastName;
    private String maternalLastName;
    private String password;

    private String userType;

    private LocalDateTime loginStartDate;
    private LocalDateTime loginEndDate;

    @JsonProperty("timeOnline")
    private String userOnlineTime;

    private String userStatus;
}
