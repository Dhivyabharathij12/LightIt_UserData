package com.lightit.practical.repository;

import com.lightit.practical.model.User;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Repository;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Repository
public class UserRepository {

    public List<User> readUsersFromFile() {
        List<User> users = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(
                new InputStreamReader(new ClassPathResource("userData.txt").getInputStream()))) {

            br.readLine();  // Skip header line

            String line;
            while ((line = br.readLine()) != null) {

                if(line.isBlank()){
                    continue;
                }
                // Assuming file is pipe-separated as: Id|Key|Type|Name|Username|PaternalLastName|MaternalLastName|Password|UserType|LoginStartDate|LoginEndDate|UserStatus
                String[] parts = line.split("\\|");

                LocalDateTime login = LocalDateTime.parse(parts[9]);
                LocalDateTime logout = LocalDateTime.parse(parts[10]);

                Duration duration = Duration.between(login, logout);
                String timeOnline = duration.toHours() + "h " + duration.toMinutesPart() + "m";

                User user = new User(
                        Integer.parseInt(parts[0]),
                        parts[1],
                        parts[2],
                        parts[3],
                        parts[4],
                        parts[5],
                        parts[6],
                        parts[7],
                        parts[8],
                        login,
                        logout,
                        timeOnline,
                        parts[11]
                );
                users.add(user);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return users;
    }
}
